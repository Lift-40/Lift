#pragma once

void timer_start(double duration);
void timer_stop(void);
int timer_timedOut(void);

