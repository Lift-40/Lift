#include <network_io.h>

#include <stdio.h>
#include <stdlib.h>

int elevator_routine(Configuration config) {
	/* code goes here */
}